# gentoo-installer
Gentoo Installer using Dialog Shell script
